drop database if exists inventory;
CREATE DATABASE inventory;
USE inventory;
CREATE TABLE `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

CREATE TABLE `orders` (
  `OrderId` varchar(100) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `ProductId` varchar(50) NOT NULL,
  `OrderDate` date DEFAULT NULL,
  `UnitSize` float DEFAULT NULL,
  `Units` float DEFAULT NULL,
  `CustomerName` varchar(50) DEFAULT NULL,
  `DealerName` varchar(50) DEFAULT NULL,
  `DealerId` varchar(50) DEFAULT NULL,
  `Invoice` blob,
  `DealerPricePerUnit` float DEFAULT NULL,
  `FreightPrice` float DEFAULT NULL,
  `TotalPrice` float DEFAULT NULL,
  `CustomerAddress` varchar(100) DEFAULT NULL,
  `CustomerPhoneNumber` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`OrderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `product` (
  `ProductId` varchar(100) NOT NULL,
  `ProductName` varchar(100) NOT NULL,
  `UnitSize` float DEFAULT NULL,
  `Quantity` float DEFAULT NULL,
  `DealerPrice` float DEFAULT NULL,
  `RetailPrice` float DEFAULT NULL,
  `RetailPriceWithFreight` float DEFAULT NULL,
  PRIMARY KEY (`ProductId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
